﻿
//A list of capital and lowercase letters as well as numbers that have been scrambled for better unpredictability

char[] jumbledAlphabet = { 'a', 'c', 'd', '1', 'B','D','G','h','I','J','P', '2', 't', 'Y', '3', '5', 'T', 'V', 'r', 's',
        'X', 'x', '7', 'Z', 'q', 'R', 'C', '4', 'b', 'z', 'e', 'u', 'f', 'A', '8', 'g', 'E', 'i', 'F', '9', 'j', 'H', 'k', 'l', 'M', 'K', 'O', 'Q', 'L', '6',
        'N', 'S', 'm', 'o', 'v', 'w', 'y', 'p', 'n', 'U', 'W'};


//declaration of original string to be encrypted and decrypted
string project = "TechScribeProject1";

//key that will be modified throughout the loop
int key = 7;

string rainbowEncryption(string textToEncrypt)
 {
      string newText = "";
      Random num = new Random();

    for (int i = 0; i < textToEncrypt.Length; i++)
    {
        //ifs required to handle Out of Bounds exceptions
        if (Array.IndexOf(jumbledAlphabet, textToEncrypt[i]) + 7 >= jumbledAlphabet.Length) { key = 0; }
        if (Array.IndexOf(jumbledAlphabet, textToEncrypt[i]) - key <= 0) { key = 0; }

        //encrypts the iterated character with key
        newText += jumbledAlphabet[Array.IndexOf(jumbledAlphabet, textToEncrypt[i]) + key];

        //subtracts the key by 1 per loop
        key--;

        //resets the key back to the originally declared 7
        if (key <= 0)
        {
            key = 7;
        }
    }

    //adds a random character to the end of the encrypted string for one extra layer of abstraction
    newText += jumbledAlphabet[num.Next(jumbledAlphabet.Length)];

      return newText;
 }
string newText = rainbowEncryption(project);
string rainbowDecryption(string textToDecrypt)
{
    //most of this code is the same as the method rainbowEncryption

    //resets the key
    key = 7;

    //removes previously added method
    textToDecrypt = textToDecrypt.Remove(textToDecrypt.Length-1,1);
    string decryptedText = "";

    for (int i = 0; i < textToDecrypt.Length; i++)
    {
        //eliminated one unnecessary if that was present in rainbowEncryption
        if (Array.IndexOf(jumbledAlphabet, textToDecrypt[i]) - key <= 0) { key = 0; }
        
        //changed subtraction instead of addition to decrypt the text
        decryptedText += jumbledAlphabet[Array.IndexOf(jumbledAlphabet, textToDecrypt[i]) - key];

        key--;
        if (key <= 0)
        {
            key = 7;
        }
    }


    return decryptedText;
 }

Console.WriteLine("This is the text to be encrypted: " + project);
Console.WriteLine("Here is the encrypted text: " + newText);
Console.WriteLine("Here is the decrypted text: " + rainbowDecryption(newText));

    


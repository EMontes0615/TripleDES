﻿using System.Security.Cryptography;
using System.Text;
// See https://aka.ms/new-console-template for more information
namespace TripleDES
{
    public class ClsTripleDES
    {

        private const string mysecurityKey = "MyTestSampleKey";

        public static string Encrypt(string TextToEncrypt)
        {
            byte[] encryptArray = UTF8Encoding.UTF8
               .GetBytes(TextToEncrypt);

            MD5CryptoServiceProvider cryptoService = new
               MD5CryptoServiceProvider();

            byte[] MysecurityKeyArray = cryptoService.ComputeHash
               (UTF8Encoding.UTF8.GetBytes(mysecurityKey));

            cryptoService.Clear();

            var MyTripleDESCryptoService = new
               TripleDESCryptoServiceProvider();

            MyTripleDESCryptoService.Key = MysecurityKeyArray;

            MyTripleDESCryptoService.Mode = CipherMode.ECB;

            MyTripleDESCryptoService.Padding = PaddingMode.PKCS7;

            var MyCrytpoTransform = MyTripleDESCryptoService
               .CreateEncryptor();

            byte[] MyresultArray = MyCrytpoTransform
               .TransformFinalBlock(encryptArray, 0,
               encryptArray.Length);

            MyTripleDESCryptoService.Clear();

            return Convert.ToBase64String(MyresultArray, 0,
               MyresultArray.Length);
        }
    static void Main(string[] args)
        {
            var text = "My Sample Text to Test DES from C#";
            var encryptedText = ClsTripleDES.Encrypt(text);
            Console.WriteLine("Before Encryption Text = " + text);
            Console.WriteLine("After Encryption Text = " +
               encryptedText);
        }

    }
}

﻿using System.IO;
using System.Security.Cryptography;
using System.Text;
// See https://aka.ms/new-console-template for more information
namespace TripleDES
{

    public class ClsTripleDES
    {




        public static string Encrypt(string TextToEncrypt)
        {
            byte[] encryptArray = UTF8Encoding.UTF8
               .GetBytes(TextToEncrypt);

            MD5CryptoServiceProvider cryptoService = new
               MD5CryptoServiceProvider();

            byte[] MysecurityKeyArray = cryptoService.ComputeHash
               (UTF8Encoding.UTF8.GetBytes(TextToEncrypt));

            cryptoService.Clear();

            var MyTripleDESCryptoService = new
               TripleDESCryptoServiceProvider();

            MyTripleDESCryptoService.Key = MysecurityKeyArray;

            MyTripleDESCryptoService.Mode = CipherMode.ECB;

            MyTripleDESCryptoService.Padding = PaddingMode.PKCS7;

            var MyCrytpoTransform = MyTripleDESCryptoService
               .CreateEncryptor();

            byte[] MyresultArray = MyCrytpoTransform
               .TransformFinalBlock(encryptArray, 0,
               encryptArray.Length);

            MyTripleDESCryptoService.Clear();

            return Convert.ToBase64String(MyresultArray, 0,
               MyresultArray.Length);
        }
        static void Main(string[] args)
        {
            var fDirectory = Environment.CurrentDirectory;
            string envpath = Directory.GetParent(fDirectory).Parent.Parent.FullName;
            string path = envpath + "\\userEmails.txt";

            using (StreamReader reader = new StreamReader(path))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var newLine = ClsTripleDES.Encrypt(line);
                    Console.WriteLine("Before Encryption Text = " + line);
                    Console.WriteLine("After Encryption Text = " + newLine +'\n');
                       
                }

            }
        }

    }
}

